package com.igarapedigital.webcurso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebcursoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebcursoApplication.class, args);
	}

}
