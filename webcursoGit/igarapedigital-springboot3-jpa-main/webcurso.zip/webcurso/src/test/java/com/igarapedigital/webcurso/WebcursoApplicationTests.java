package com.igarapedigital.webcurso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebcursoApplicationTests {

	@Test
	void contextLoads() {
	}

}
